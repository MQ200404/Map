class Credentials {

  static var email = '';
  static var name = '';

}
