package com.example.hi_world;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
